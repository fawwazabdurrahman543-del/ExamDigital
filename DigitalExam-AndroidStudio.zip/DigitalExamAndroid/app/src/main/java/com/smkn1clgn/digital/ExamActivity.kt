package com.smkn1clgn.digital

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class ExamActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val examUrl = intent.getStringExtra(ExamConfig.EXTRA_EXAM_URL)
        if (examUrl == null || !ExamConfig.isAllowed(examUrl)) {
            finish()
            return
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
        }
        setContentView(FrameLayout(this).apply {
            addView(
                webView,
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            addView(
                progress,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        })

        setupWebView()

        // Tombol back sengaja diabaikan selama ujian (tanpa pencatatan apa pun).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* diabaikan */ }
        })

        enterImmersive()
        tryStartLockTask()
        webView.loadUrl(examUrl)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
        }
        webView.webViewClient = object : WebViewClient() {
            // true = navigasi diblokir (di luar host ujian)
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = !ExamConfig.isAllowed(request.url.toString())

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String) {
                progress.visibility = View.GONE
                // Asumsi: halaman review Moodle = ujian selesai. Sesuaikan dengan versi aslimu.
                if (url.contains("/mod/quiz/review.php")) finishExam()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
    }

    override fun onDestroy() {
        runCatching { stopLockTask() }
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }

    private fun finishExam() {
        runCatching { stopLockTask() }
        finish()
    }

    private fun tryStartLockTask() {
        try {
            startLockTask()
        } catch (_: Exception) {
            // Gagal masuk lock task: dibiarkan diam, ujian tetap berjalan.
        }
    }

    private fun enterImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    // ── TITIK PASANG DETEKTOR (sengaja kosong) ───────────────────────────
    // Tempat memasang kodemu nanti:
    //   - override onStop(), onUserLeaveHint(), onWindowFocusChanged(hasFocus),
    //     onMultiWindowModeChanged(...), onPictureInPictureModeChanged(...)
    //   - handleOnBackPressed() pada callback di onCreate
    //   - shouldOverrideUrlLoading() pada WebViewClient di atas
    //   - blok catch di tryStartLockTask()
    // ─────────────────────────────────────────────────────────────────────
}
