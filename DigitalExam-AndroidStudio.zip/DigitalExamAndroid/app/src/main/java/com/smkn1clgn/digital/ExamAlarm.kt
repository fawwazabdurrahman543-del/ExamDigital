package com.smkn1clgn.digital

import android.content.Context
import android.media.MediaPlayer

/**
 * Pemutar suara alarm. Saat ini TIDAK dipanggil dari mana pun.
 *
 * Untuk mengganti suaranya: timpa file res/raw/navigation_alarm.wav dengan
 * file barumu (nama sama), atau ubah R.raw.navigation_alarm di bawah ke nama baru.
 */
object ExamAlarm {
    private var player: MediaPlayer? = null

    fun play(context: Context) {
        stop()
        val mp = MediaPlayer.create(context.applicationContext, R.raw.navigation_alarm) ?: return
        mp.setOnCompletionListener { stop() }
        player = mp
        mp.start()
    }

    fun stop() {
        player?.let {
            runCatching { if (it.isPlaying) it.stop() }
            it.release()
        }
        player = null
    }
}
