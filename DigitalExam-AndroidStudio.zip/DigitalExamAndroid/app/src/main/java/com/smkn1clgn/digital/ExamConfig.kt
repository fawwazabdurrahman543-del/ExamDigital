package com.smkn1clgn.digital

import android.net.Uri

object ExamConfig {
    const val EXTRA_EXAM_URL = "EXAM_URL"

    // Host server ujian yang diizinkan (diambil dari APK; ganti bila server berubah)
    const val ALLOWED_HOST = "103.4.167.175"

    fun isAllowed(url: String): Boolean {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        val schemeOk = uri.scheme == "http" || uri.scheme == "https"
        return schemeOk && uri.host == ALLOWED_HOST
    }
}
