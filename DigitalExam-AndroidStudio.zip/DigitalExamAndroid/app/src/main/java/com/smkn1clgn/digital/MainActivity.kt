package com.smkn1clgn.digital

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : AppCompatActivity() {

    private val scanLauncher = registerForActivityResult(ScanContract()) { result ->
        val content = result.contents ?: return@registerForActivityResult
        openExam(content.trim())
    }

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startScan() else toast("Izin kamera dibutuhkan untuk scan QR")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // UI dibuat lewat kode agar tidak bentrok dengan layout/ID di proyekmu.
        // Ganti dengan layout XML aslimu kapan saja.
        val pad = (24 * resources.displayMetrics.density).toInt()
        val tvTitle = TextView(this).apply {
            text = "DIGITAL"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        val tvInfo = TextView(this).apply {
            text = "Arahkan kamera ke QR ujian dari panitia"
            gravity = Gravity.CENTER
        }
        val scanButton = Button(this).apply {
            text = "Scan QR Ujian"
            setOnClickListener { onScanClicked() }
        }
        val urlInput = EditText(this).apply {
            hint = "atau tempel tautan ujian"
            setSingleLine()
        }
        val openButton = Button(this).apply {
            text = "Buka"
            setOnClickListener { openExam(urlInput.text.toString().trim()) }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            addView(tvTitle)
            addView(tvInfo)
            addView(scanButton)
            addView(
                urlInput,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            addView(openButton)
        })
    }

    private fun onScanClicked() {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) startScan() else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startScan() {
        val options = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt("Arahkan kamera ke QR ujian dari panitia")
        scanLauncher.launch(options)
    }

    private fun openExam(raw: String) {
        if (raw.isEmpty()) return
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        if (uri == null || (uri.scheme != "http" && uri.scheme != "https")) {
            toast("Format QR tidak dikenali")
            return
        }
        if (!ExamConfig.isAllowed(raw)) {
            toast("Domain tidak dikenali sebagai server ujian resmi")
            return
        }
        startActivity(
            Intent(this, ExamActivity::class.java)
                .putExtra(ExamConfig.EXTRA_EXAM_URL, raw)
        )
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
