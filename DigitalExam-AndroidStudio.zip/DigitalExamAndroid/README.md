# DIGITAL Exam — Android Studio project

Proyek Android berbasis Kotlin yang menggabungkan empat file sumber yang diberikan.

## Persyaratan
- Android Studio versi yang mendukung Android Gradle Plugin 8.9.2
- JDK 17
- Android SDK Platform 35
- Koneksi internet saat Gradle pertama kali mengunduh plugin dan dependensi

## Membuka proyek
1. Ekstrak ZIP.
2. Android Studio → **Open** → pilih folder `DigitalExam` (folder yang berisi `settings.gradle.kts`).
3. Tunggu proses Gradle Sync selesai.
4. Sambungkan perangkat Android atau jalankan emulator.
5. Pilih **Run** untuk memasang aplikasi.

## Membuat APK
Di Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

APK debug biasanya tersedia di:
`app/build/outputs/apk/debug/app-debug.apk`

## Konfigurasi server
Host yang diizinkan saat ini ditetapkan di `ExamConfig.kt`:
`103.4.167.175`

Aplikasi hanya menerima URL HTTP/HTTPS dengan host tersebut. Jika alamat server ujian berubah, ubah `ALLOWED_HOST` pada `ExamConfig.kt`.

`usesCleartextTraffic="true"` disertakan karena konfigurasi saat ini mengizinkan URL HTTP. Jika server sudah sepenuhnya menggunakan HTTPS, sebaiknya nonaktifkan cleartext traffic.

## Alarm
`ExamAlarm.kt` mengharapkan resource `res/raw/navigation_alarm.wav`. Proyek ini menyertakan nada beep sederhana sebagai placeholder. Fungsi alarm belum dipanggil oleh aktivitas mana pun, sesuai komentar pada kode sumber.

## Catatan penting tentang Lock Task
Pemanggilan `startLockTask()` tidak otomatis menjadikan perangkat kiosk terkelola. Pada perangkat yang tidak dikonfigurasi sebagai device owner / tidak memasukkan aplikasi ke daftar izin Lock Task, Android dapat menampilkan mode screen pinning atau menolak penguncian. Uji perilaku ini pada perangkat sekolah sebelum digunakan dalam ujian sungguhan.

## Catatan build
Arsip ini berisi konfigurasi proyek Android Gradle, tetapi tidak menyertakan Android SDK maupun hasil APK yang sudah dikompilasi. Gradle akan mengunduh plugin dan dependensi ketika proyek disinkronkan.
